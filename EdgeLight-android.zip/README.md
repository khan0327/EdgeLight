# Edge Light

An Android app that shows a moving light around the edge of the screen. It runs as a foreground service, so it keeps going after the app is closed, until you turn it off from the app or from the notification.

## Get the APK (no computer setup needed)

1. Create a free account on github.com and make a new **public** repository.
2. Upload everything in this folder to the repository, keeping the folder structure. The `.github/workflows/build.yml` file must end up at exactly that path.
3. Open the **Actions** tab. The "Build APK" job starts by itself and takes about 5 minutes.
4. When it turns green, open the **Releases** page of your repository. Download `EdgeLight.apk` from the newest release.
5. Share the Releases page link. Anyone can download the APK from it.

## Install on a phone

1. Open the download link on the phone and download `EdgeLight.apk`.
2. Tap the file. If asked, allow "Install unknown apps" for the browser or file manager you used.
3. If Play Protect warns about an unknown developer, choose **Install anyway**.
4. Open Edge Light, tap **Allow drawing over other apps**, switch the permission on, and go back.
5. Tap **Turn on**.

## Notes

- Minimum Android version: 8.0.
- On some phones (Xiaomi, Oppo, Vivo, Samsung), open Settings > Apps > Edge Light > Battery and set it to Unrestricted. Otherwise the system may stop the light.
- The light ignores touches, so the phone works normally underneath it.
- This builds a debug APK, which is fine for sharing directly. Google Play needs a signed release bundle (.aab) and a Play Console account, which is a separate step.
