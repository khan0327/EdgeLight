package com.edgelight.app

import android.content.Context

/** Settings shared by the settings screen and the overlay service (same process). */
object Config {
    const val MODE_COMET = 0
    const val MODE_RAINBOW = 1
    const val MODE_PULSE = 2

    @Volatile var running = false
    @Volatile var mode = MODE_COMET
    @Volatile var tailColor = 0xFF2A7BFF.toInt()
    @Volatile var headColor = 0xFF7DF9FF.toInt()
    @Volatile var lapSeconds = 4f
    @Volatile var thicknessDp = 5f
    @Volatile var glowDp = 10f
    @Volatile var radiusDp = 40f
    @Volatile var tailPercent = 40

    private const val FILE = "edge_light"

    fun load(ctx: Context) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        mode = p.getInt("mode", mode)
        tailColor = p.getInt("tailColor", tailColor)
        headColor = p.getInt("headColor", headColor)
        lapSeconds = p.getFloat("lapSeconds", lapSeconds)
        thicknessDp = p.getFloat("thicknessDp", thicknessDp)
        glowDp = p.getFloat("glowDp", glowDp)
        radiusDp = p.getFloat("radiusDp", radiusDp)
        tailPercent = p.getInt("tailPercent", tailPercent)
    }

    fun save(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt("mode", mode)
            .putInt("tailColor", tailColor)
            .putInt("headColor", headColor)
            .putFloat("lapSeconds", lapSeconds)
            .putFloat("thicknessDp", thicknessDp)
            .putFloat("glowDp", glowDp)
            .putFloat("radiusDp", radiusDp)
            .putInt("tailPercent", tailPercent)
            .apply()
    }
}
