package com.edgelight.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/** Draws the moving light along the rounded edge of the screen. Redraws itself every frame. */
class EdgeView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()
    private val seg = Path()
    private val pm = PathMeasure()
    private val rot = Matrix()
    private val box = RectF()

    private var len = 1f
    private var kw = -1f
    private var kh = -1f
    private var kt = -1f
    private var kr = -1f
    private var phase = 0f
    private var lastNanos = 0L

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) {
            postInvalidateOnAnimation()
            return
        }
        val d = resources.displayMetrics.density
        val thick = Config.thicknessDp * d
        val glow = Config.glowDp * d
        val radius = Config.radiusDp * d

        ensurePath(w, h, thick, radius)
        advance()

        when (Config.mode) {
            Config.MODE_COMET -> drawComet(canvas, thick, glow)
            Config.MODE_RAINBOW -> drawSweep(canvas, thick, glow, true)
            else -> drawSweep(canvas, thick, glow, false)
        }
        postInvalidateOnAnimation()
    }

    private fun ensurePath(w: Float, h: Float, thick: Float, radius: Float) {
        if (w == kw && h == kh && thick == kt && radius == kr) return
        kw = w; kh = h; kt = thick; kr = radius
        val inset = thick / 2f
        box.set(inset, inset, w - inset, h - inset)
        val r = max(0f, min(radius - inset, min(box.width(), box.height()) / 2f))
        path.rewind()
        path.addRoundRect(box, r, r, Path.Direction.CW)
        pm.setPath(path, true)
        len = max(pm.length, 1f)
    }

    private fun advance() {
        val now = System.nanoTime()
        if (lastNanos != 0L) {
            val dt = min((now - lastNanos) / 1_000_000_000f, 0.1f)
            phase = (phase + dt / max(Config.lapSeconds, 0.5f)) % 1f
        }
        lastNanos = now
    }

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
        return Color.rgb(r, g, bl)
    }

    /** Draws the part of the edge between two distances along the path, wrapping past the end. */
    private fun segment(canvas: Canvas, s0: Float, s1: Float) {
        val a = ((s0 % len) + len) % len
        val b = ((s1 % len) + len) % len
        seg.rewind()
        if (b >= a) {
            pm.getSegment(a, b, seg, true)
        } else {
            pm.getSegment(a, len, seg, true)
            pm.getSegment(0f, b, seg, true)
        }
        canvas.drawPath(seg, paint)
    }

    private fun drawComet(canvas: Canvas, thick: Float, glow: Float) {
        val tail = Config.tailColor
        val head = Config.headColor
        paint.shader = null
        paint.strokeCap = Paint.Cap.BUTT

        // faint track so the edge is always visible
        paint.color = tail
        paint.alpha = 50
        paint.strokeWidth = max(1f, thick * 0.35f)
        canvas.drawPath(path, paint)

        val headPos = phase * len
        val tailLen = len * Config.tailPercent / 100f

        if (glow > 0f) {
            cometPass(canvas, headPos, tailLen, thick + glow, 14, 0.12f, tail, head)
            cometPass(canvas, headPos, tailLen, thick + glow * 0.5f, 20, 0.22f, tail, head)
        }
        cometPass(canvas, headPos, tailLen, thick, 48, 1f, tail, head)

        // bright rounded head
        paint.color = head
        paint.alpha = 255
        paint.strokeWidth = thick
        paint.strokeCap = Paint.Cap.ROUND
        segment(canvas, headPos - thick * 0.5f, headPos)
    }

    private fun cometPass(
        canvas: Canvas, headPos: Float, tailLen: Float, width: Float,
        n: Int, alphaMul: Float, tail: Int, head: Int
    ) {
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.BUTT
        val step = tailLen / n
        for (k in n - 1 downTo 0) {
            val u = k.toFloat() / n
            paint.color = lerpColor(head, tail, u)
            paint.alpha = (255f * alphaMul * (1f - u).pow(1.6f)).toInt().coerceIn(0, 255)
            segment(canvas, headPos - (k + 1) * step, headPos - k * step + 0.75f)
        }
    }

    private fun drawSweep(canvas: Canvas, thick: Float, glow: Float, rainbow: Boolean) {
        val cx = width / 2f
        val cy = height / 2f
        val colors = if (rainbow) {
            intArrayOf(Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA, Color.RED)
        } else {
            intArrayOf(Config.tailColor, Config.headColor, Config.tailColor)
        }
        val shader = SweepGradient(cx, cy, colors, null)
        rot.reset()
        rot.postRotate(phase * 360f, cx, cy)
        shader.setLocalMatrix(rot)
        paint.shader = shader
        paint.strokeCap = Paint.Cap.BUTT

        val base = if (rainbow) {
            255
        } else {
            (110f + 145f * (0.5f + 0.5f * sin(phase * 2f * PI.toFloat()))).toInt()
        }

        if (glow > 0f) {
            paint.strokeWidth = thick + glow
            paint.alpha = (base * 0.12f).toInt()
            canvas.drawPath(path, paint)
            paint.strokeWidth = thick + glow * 0.5f
            paint.alpha = (base * 0.22f).toInt()
            canvas.drawPath(path, paint)
        }
        paint.strokeWidth = thick
        paint.alpha = base
        canvas.drawPath(path, paint)
        paint.shader = null
    }
}
