package com.edgelight.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val bgColor = Color.parseColor("#06080C")
    private val fgColor = Color.parseColor("#E9EEF6")
    private val mutedColor = Color.parseColor("#8E9AAE")
    private val accentColor = Color.parseColor("#7DF9FF")
    private val surfaceColor = Color.parseColor("#151D29")

    private data class Preset(val name: String, val mode: Int, val tail: String, val head: String)

    private val presets = listOf(
        Preset("Ice", Config.MODE_COMET, "#2A7BFF", "#7DF9FF"),
        Preset("Ember", Config.MODE_COMET, "#FF4D1F", "#FFD9A0"),
        Preset("Mint", Config.MODE_COMET, "#0FB981", "#D9FFF0"),
        Preset("Aurora", Config.MODE_RAINBOW, "#7C5CFF", "#5CFFD6"),
        Preset("Violet", Config.MODE_PULSE, "#7C3AED", "#F0ABFC")
    )

    private lateinit var status: TextView
    private lateinit var permButton: Button
    private lateinit var toggleButton: Button
    private val styleButtons = mutableListOf<Button>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Config.load(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(24), dp(24), dp(24), dp(40))

        col.addView(textView("EDGE LIGHT", 12f, accentColor, false), params(0))
        col.addView(textView("Light around your screen", 28f, fgColor, true), params(6))
        status = textView("", 14f, mutedColor, false)
        col.addView(status, params(8))

        permButton = button("Allow drawing over other apps") { openOverlaySettings() }
        col.addView(permButton, params(16))
        toggleButton = button("Turn on") { toggle() }
        col.addView(toggleButton, params(8))

        col.addView(textView("STYLE", 12f, mutedColor, false), params(28))
        val modeNames = listOf("Comet", "Rainbow", "Pulse")
        val modeButtons = modeNames.mapIndexed { i, name ->
            val b = button(name) {
                Config.mode = i
                Config.save(this)
                refresh()
            }
            styleButtons.add(b)
            b
        }
        col.addView(row(modeButtons), params(8))

        col.addView(textView("PRESETS", 12f, mutedColor, false), params(24))
        val presetButtons = presets.map { p ->
            button(p.name) {
                Config.mode = p.mode
                Config.tailColor = Color.parseColor(p.tail)
                Config.headColor = Color.parseColor(p.head)
                Config.save(this)
                refresh()
            }
        }
        col.addView(row(presetButtons.take(3)), params(8))
        col.addView(row(presetButtons.drop(3)), params(8))

        col.addView(textView("ADJUST", 12f, mutedColor, false), params(24))
        col.addView(slider("Lap time", 1f, 12f, 0.5f, Config.lapSeconds, "s") { Config.lapSeconds = it }, params(0))
        col.addView(slider("Thickness", 2f, 16f, 1f, Config.thicknessDp, "dp") { Config.thicknessDp = it }, params(0))
        col.addView(slider("Glow", 0f, 20f, 1f, Config.glowDp, "dp") { Config.glowDp = it }, params(0))
        col.addView(slider("Corner radius", 0f, 60f, 1f, Config.radiusDp, "dp") { Config.radiusDp = it }, params(0))
        col.addView(slider("Tail length (Comet)", 10f, 90f, 1f, Config.tailPercent.toFloat(), "%") { Config.tailPercent = it.toInt() }, params(0))

        col.addView(
            textView(
                "On some phones, set battery use for Edge Light to Unrestricted so the system does not stop the light.",
                12f, mutedColor, false
            ),
            params(28)
        )

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bgColor)
        scroll.clipToPadding = false
        scroll.addView(col)
        scroll.setOnApplyWindowInsetsListener { v, insets ->
            if (Build.VERSION.SDK_INT >= 30) {
                val b = insets.getInsets(WindowInsets.Type.systemBars())
                v.setPadding(b.left, b.top, b.right, b.bottom)
            } else {
                v.setPadding(
                    insets.systemWindowInsetLeft, insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight, insets.systemWindowInsetBottom
                )
            }
            insets
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        permButton.visibility = if (canDraw) View.GONE else View.VISIBLE
        toggleButton.text = if (Config.running) "Turn off" else "Turn on"
        status.text = when {
            !canDraw -> "Edge Light needs permission to draw over other apps."
            Config.running -> "The light is on. It keeps running after you close this app."
            else -> "The light is off."
        }
        styleButtons.forEachIndexed { i, b -> b.alpha = if (i == Config.mode) 1f else 0.45f }
    }

    private fun toggle() {
        if (Config.running) {
            startService(Intent(this, EdgeLightService::class.java).apply {
                action = EdgeLightService.ACTION_STOP
            })
            Config.running = false
        } else {
            if (!Settings.canDrawOverlays(this)) {
                openOverlaySettings()
                return
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            Config.save(this)
            startForegroundService(Intent(this, EdgeLightService::class.java))
            Config.running = true
        }
        refresh()
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    // ---- small UI helpers ----

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun params(top: Int): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        p.topMargin = dp(top)
        return p
    }

    private fun textView(s: String, size: Float, color: Int, bold: Boolean): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.setAllCaps(false)
        b.setTextColor(fgColor)
        b.setBackgroundColor(surfaceColor)
        b.setOnClickListener { onClick() }
        return b
    }

    private fun row(views: List<View>): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (v in views) {
            val p = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            p.setMargins(dp(3), 0, dp(3), 0)
            r.addView(v, p)
        }
        return r
    }

    private fun slider(
        title: String, lo: Float, hi: Float, step: Float, value: Float, unit: String,
        onChange: (Float) -> Unit
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(14), 0, 0)

        val label = textView("", 14f, fgColor, false)
        val bar = SeekBar(this)
        bar.max = Math.round((hi - lo) / step)
        bar.progress = Math.round((value - lo) / step)

        fun show(v: Float) {
            val shown = if (step < 1f) "%.1f".format(v) else v.toInt().toString()
            label.text = "$title   $shown $unit"
        }
        show(value)

        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val v = lo + progress * step
                show(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                Config.save(this@MainActivity)
            }
        })

        box.addView(label)
        box.addView(bar)
        return box
    }
}
